/*
 * ActiveTransaction.java
 *
 * List of active transactions.
 *
 * You must follow the coding standards distributed
 * on the class web page.
 *
 * (C) 2011 Mike Dahlin
 *
 */
public class ActiveTransactionList{

    /*
     * You can alter or add to these suggested methods.
     */

    public void put(Transaction trans){
        System.exit(-1); // TBD
    }

    public Transaction get(TransID tid){
        System.exit(-1); // TBD
        return null;
    }

    public Transaction remove(TransID tid){
        System.exit(-1); // TBD
        return null;
    }


}